package org.izv.ad.jmunoz.ficherovinos.files;

import java.io.File;

public class DeleteFile extends Thread{

    private File file;

    //constructor
    public DeleteFile(File file) {
        this.file = file;
    }

    @Override
    public void run() {
        //elimina el archivo.csv
        File f = new File(file, WriteFile.fileName);
        f.delete();
    }
}
